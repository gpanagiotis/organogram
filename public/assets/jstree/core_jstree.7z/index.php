<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>jsTree test</title>
    <!-- 2 load the theme CSS file -->
    <link rel="stylesheet" href="dist/themes/default/style.min.css"/>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>


    <style>
        .jstree-open > jstree-anchor .jstree-icon:before {
            content: "\2212";
        }
    </style>

</head>
<body>
<!-- 3 setup a container element -->
<div id="jstree">
    <!-- in this example the tree is populated from inline HTML -->
    <!--    <ul>-->
    <!--        <li>Root node 1-->
    <!--            <ul>-->
    <!--                <li id="child_node_1">Child node 1</li>-->
    <!--                <li>Child node 2</li>-->
    <!--            </ul>-->
    <!--        </li>-->
    <!--        <li>Root node 2</li>-->
    <!--    </ul>-->
</div>
<button>demo button</button>

<!-- 4 include the jQuery library -->
<script src="dist/libs/jquery.js"></script>
<!-- 5 include the minified jstree source -->
<script src="dist/jstree.min.js"></script>
<script>
    $(document).ready(function () {


        var tree = [
            {"id": "ajson1", "parent": "#", "text": "Simple root node"},
            {"id": "ajson2", "parent": "#", "text": "Root node 2"},
            {"id": "ajson3", "parent": "ajson2", "text": "Child 1"},
            {"id": "ajson4", "parent": "ajson2", "text": "Child 2"},
        ]


        //$.ajax.success(data);
        function getAjaxTree(callBack) {
            $.ajax({
                url: "fetch.php",
                method: "POST",
                dataType: "json",
                success: function (data) {
                    //setTimeout(function(){callBack(data);},3000);
                    callBack(data);
                }
            });
        }


        getAjaxTree(function (data) {
            //console.log(data);


            $('#jstree').jstree({

                "types": {
                    "default": {
                        "icon": "glyphicon glyphicon-envelope"
                    },
                },

                'core': {
                    "animation": 0,
                    "check_callback": true,
                    "themes": {"stripes": true},
                    'data': data
                },
                'data': function (node) {
                    console.log('init:' + node.id);
                    return {'id': node.id};
                },

                "plugins": [
                    // "checkbox",
                    "contextmenu",
                    "contextmenu",
                    "dnd",
                    "massload",
                    "search",
                    "sort",
                    "state",
                    "types",
                    "unique",
                    "wholerow",
                    "changed",
                    "conditionalselect"
                ]


            });

        });


        // 6 create an instance when the DOM is ready
        // $('#jstree').jstree();
        // 7 bind to events triggered on the tree
        $('#jstree').on("changed.jstree", function (e, data) {
            console.log('changed:' + data.selected);
        });

        $('#jstree').on("create_node.jstree", function (e, data) {
            console.log('create:' + data.selected, e, data);
        });

        $('#jstree').on("rename_node.jstree", function (e, data) {


            console.log(e, data);
            console.log('data:', data.node);

            var node = data.node;
            var info = {'id': node.id, 'name': node.text, 'parent_id': node.parent, 'is_manager': 0};
            //console.log('rename:',  data.node);
            //console.log('info', JSON.stringify(info));

            $.ajax({
                url: "create-node.php",
                method: "POST",
                dataType: "json",
                data: info, //task:'delete'
                success: function (data) {
                    //data: {status:'ok', new_id:1345} OR  {status:'error', message:'Database error'}
                    if (data.status == 'ok') {
                        //node.id = data.new_id;
                        $('#jstree').jstree(true).set_id(node, data.new_id);
                    } else {
                        alert(data.message);
                    }
                }
            });

        });

        // 8 interact with the tree - either way is OK
        $('button').on('click', function () {
            $('#jstree').jstree(true).select_node('child_node_1');
            $('#jstree').jstree('select_node', 'child_node_1');
            $.jstree.reference('#jstree').select_node('child_node_1');
        });


    });
</script>
</body>
</html>