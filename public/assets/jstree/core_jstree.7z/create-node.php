<?php
$connect = mysqli_connect("localhost", "root", "", "testing1");
$connect->set_charset("utf8");


if (isset($_POST['name']) && isset($_POST['parent_id']) && isset($_POST['id'])) :
    $name = $_POST['name'];
    $pid = $_POST['parent_id'];
    $ord = 1000;
    $is_mng = 0;
    $id = (int)$_POST['id']; //0 -> number


    //$query = sprintf("SELECT COUNT(*) FROM organogram where id=%i",$id);
    //$is_ok = mysqli_query($connect, $query);

    if ($id > 0) { //updated
        $query = sprintf("UPDATE organogram SET name='%s', parent_id=%s,ordering=%s,is_manager=%s WHERE id=%s", $name, $pid, $ord, $is_mng, $id); //order by ordering desc
    } else {
        $query = sprintf("INSERT INTO organogram (name,parent_id,ordering,is_manager) VALUES ('%s',%s,%s,%s)", $name, $pid, $ord, $is_mng); //order by ordering desc
        //$result = mysqli_query($connect, $query);
    }
    //var_dump($query);

    $is_ok = mysqli_query($connect, $query);

    if ($is_ok) {
        $id = mysqli_insert_id($connect);
        $res = ['status' => 'ok', 'new_id' => $id];
    } else {
        $res = ['status' => 'error', 'message' => 'Error insert'];
    }

    echo json_encode($res);
else:
    echo json_encode(['status' => 'error', 'message' => 'Invalid arguments']);
endif;